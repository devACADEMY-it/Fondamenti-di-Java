/*
 * Fondamenti di Java
 * Primo progetto con Eclipse
 *
 * Disponibile su devACADEMY.it
 */

public class Hello {

	public static void main(String[] args) {

		// Qui scriveremo il primo programma in Java

	}

}
