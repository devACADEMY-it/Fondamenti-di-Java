/*
 * Fondamenti di Java
 * Membri privati
 * 
 * Disponibile su devACADEMY.it
 */

public class MembriPrivati {

	public static void main(String[] args) {
		
		Persona p = new Persona();
		p.setNome("Paolo");
		p.setCognome("Rossi");
		p.setEta(34);

		System.out.println(p.nomeCompleto());
		System.out.println(p.getNome());

	}

}