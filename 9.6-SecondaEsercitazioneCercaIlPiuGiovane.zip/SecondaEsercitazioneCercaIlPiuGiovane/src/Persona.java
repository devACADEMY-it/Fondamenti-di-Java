/*
 * Fondamenti di Java
 * Seconda Esercitazione: "Cerca il più giovane"
 * 
 * Disponibile su devACADEMY.it
 */

public class Persona {
	private String nome;
	private String cognome;
	private int eta;
	
	Persona(String nome, String cognome, int eta) {
		this.nome = nome;
		this.cognome = cognome;
		this.eta = eta;
	}

	public int getEta() {
		return eta;
	}


	public String descrizione(){
		return nome + " " + cognome + " di anni " + eta;
	}
	
}