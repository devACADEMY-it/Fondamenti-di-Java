/*
 * Fondamenti di Java
 * Ereditarietà
 * 
 * Disponibile su devACADEMY.it
 */

public class Ereditarieta {

	public static void main(String[] args) {
		
		Studente s = new Studente();
		s.setNome("Paolo");
		s.setCognome("Rossi");
		s.setEta(34);
		s.setMatricola("AB123456");
		
		System.out.println(s.nomeCompleto() + " - " + s.getMatricola());

	}

}