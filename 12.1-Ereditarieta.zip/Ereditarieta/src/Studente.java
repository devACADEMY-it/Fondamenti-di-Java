/*
 * Fondamenti di Java
 * Ereditarietà
 * 
 * Disponibile su devACADEMY.it
 */

public class Studente extends Persona {
	
	private String matricola;

	public String getMatricola() {
		return matricola;
	}

	public void setMatricola(String matricola) {
		this.matricola = matricola;
	}

}