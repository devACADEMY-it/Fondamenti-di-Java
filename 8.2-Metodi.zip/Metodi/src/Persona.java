/*
 * Fondamenti di Java
 * I metodi
 * 
 * Disponibile su devACADEMY.it
 */

public class Persona {
	String nome;
	String cognome;
	int eta;
	
	String nomeCompleto(){
		return nome + " " + cognome;
	}
}