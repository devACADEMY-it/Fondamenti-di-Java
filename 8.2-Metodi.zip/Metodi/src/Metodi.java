/*
 * Fondamenti di Java
 * I metodi
 * 
 * Disponibile su devACADEMY.it
 */

public class Metodi {

	public static void main(String[] args) {
		
		Persona p = new Persona();
		p.nome = "Paolo";
		p.cognome = "Rossi";
		p.eta = 25;
		
		Persona p1 = new Persona();
		p1.nome = "Enzo";
		p1.cognome = "Verdi";
		p1.eta = 56;
		
		String nc = p.nomeCompleto();
		
		System.out.println(nc);
		System.out.println(p1.nomeCompleto());

	}

}