/*
 * Fondamenti di Java
 * ArrayList
 * 
 * Disponibile su devACADEMY.it
 */

import java.util.ArrayList;

public class EsempioListe {

	public static void main(String[] args) {
		
		ArrayList<String> lista = new ArrayList<String>();
		
		lista.add("Carlo");
		lista.add("Paolo");
		lista.add("Luca");
		lista.add("Aldo");

		System.out.println("Dimensione: " + lista.size());
		
		for (int i=0; i<lista.size(); i++){
			System.out.println(lista.get(i));
		}
		
		System.out.println("=================");
		
		for (String s: lista){
			
			System.out.println(s);
		}
	}

}