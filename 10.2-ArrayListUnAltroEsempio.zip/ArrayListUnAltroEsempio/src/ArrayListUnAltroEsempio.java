/*
 * Fondamenti di Java
 * ArrayList: un altro esempio
 * 
 * Disponibile su devACADEMY.it
 */

import java.util.ArrayList;

public class ArrayListUnAltroEsempio {

	public static void main(String[] args) {
		
		ArrayList<Persona> lista = new ArrayList<Persona>();
		lista.add(new Persona("Paolo", "Rossi", 45));
		lista.add(new Persona("Luigi", "Bianchi", 71));
		lista.add(new Persona("Enzo", "Verdi", 26));
		
		System.out.println("Dimensione: " + lista.size());
		
		for (Persona p: lista){
			System.out.println(p.nomeCompleto());
		}

	}

}