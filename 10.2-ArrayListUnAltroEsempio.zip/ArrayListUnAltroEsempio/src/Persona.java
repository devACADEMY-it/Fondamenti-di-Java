/*
 * Fondamenti di Java
 * ArrayList: un altro esempio
 * 
 * Disponibile su devACADEMY.it
 */

public class Persona {
	private String nome;
	private String cognome;
	private int eta;
	
	Persona(String n, String c, int e) {
		nome = n;
		cognome = c;
		eta = e;
	}
	
	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getCognome() {
		return cognome;
	}

	public void setCognome(String cognome) {
		this.cognome = cognome;
	}

	public int getEta() {
		return eta;
	}

	public void setEta(int eta) {
		this.eta = eta;
	}

	String nomeCompleto(){
		return cognome + " " + nome + " di anni " + eta;
	}
	
	boolean seiMaggiorenne(){
		if (eta >= 18){
			return true; // Se viene eseguito questo return il prossimo verrà saltato
		}
		return false;
	}
}