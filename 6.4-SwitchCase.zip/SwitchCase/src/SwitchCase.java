/*
 * Fondamenti di Java
 * Switch…Case
 * 
 * Disponibile su devACADEMY.it
 */

public class SwitchCase {

	public static void main(String[] args) {
		
		int numero = 10;
		
		switch (numero) {
			case 10:
				System.out.println("Vale 10");
				break;
			case 20:
				System.out.println("Vale 20");
				break;
			default:
				System.out.println("Nè 10 nè 20");
		}

	}

}