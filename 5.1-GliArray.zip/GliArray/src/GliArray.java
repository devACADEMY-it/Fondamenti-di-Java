/*
 * Fondamenti di Java
 * Gli array
 * 
 * Disponibile su devACADEMY.it
 */

public class GliArray {

	public static void main(String[] args) {
		
		int [] valori = new int[10];
		
		valori[0] = 40;
		valori[5] = 24;
		
		System.out.println(valori[5]);
		System.out.println(valori[5]*2);
		System.out.println(valori[5]+valori[0]);
		System.out.println(valori[8]);
		
		// L'istruzione che segue causerà un errore a runtime
		System.out.println(valori[10]);
	}

}