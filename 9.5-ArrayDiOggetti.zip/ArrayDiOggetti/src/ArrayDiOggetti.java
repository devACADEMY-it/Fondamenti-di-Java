/*
 * Fondamenti di Java
 * Array di oggetti
 * 
 * Disponibile su devACADEMY.it
 */

public class ArrayDiOggetti {

	public static void main(String[] args) {
		
		Persona persone[] = new Persona[10];
		
		persone[0] = new Persona("Paolo", "Rossi", 18);
		persone[3] = new Persona("Nino", "Bianchi", 54);
		persone[7] = new Persona("Silvio", "Verdi", 22);
		
		for (int i = 0; i < persone.length; i++) {
			if(persone[i] != null){
				System.out.println(persone[i].nomeCompleto());
			}
		}

	}

}