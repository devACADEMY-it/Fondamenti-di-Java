/*
 * Fondamenti di Java
 * Le stringhe
 * 
 * Disponibile su devACADEMY.it
 */

public class LeStringhe {

	public static void main(String[] args) {
		
		String frase = "Domani è un altro giorno";

		System.out.println(frase);
		System.out.println(frase.toUpperCase());
		System.out.println(frase.replace("giorno", "mese"));
		System.out.println(frase.length());
	}

}