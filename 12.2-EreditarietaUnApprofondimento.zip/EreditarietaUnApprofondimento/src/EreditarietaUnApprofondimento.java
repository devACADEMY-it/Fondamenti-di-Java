/*
 * Fondamenti di Java
 * Ereditarietà: un approfondimento
 * 
 * Disponibile su devACADEMY.it
 */

public class EreditarietaUnApprofondimento {

	public static void main(String[] args) {
		
		Studente s = new Studente("Paolo", "Rossi","AB123456", 45);
		
		System.out.println(s.nomeCompleto());
		
	}

}