/*
 * Fondamenti di Java
 * Ereditarietà: un approfondimento
 * 
 * Disponibile su devACADEMY.it
 */

public class Studente extends Persona {
	
	private String matricola;
	
	Studente(String n, String c, String m, int e) {
		matricola = m;
		nome = n;
		cognome = c;
		eta = e;
	}

	public String getMatricola() {
		return matricola;
	}

	public void setMatricola(String matricola) {
		this.matricola = matricola;
	}
	
	@Override
	String nomeCompleto() {
		String s = super.nomeCompleto() + " - " + matricola;
		return s;
	}

}
