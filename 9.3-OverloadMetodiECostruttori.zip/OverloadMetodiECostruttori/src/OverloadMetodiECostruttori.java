/*
 * Fondamenti di Java
 * Overload di metodi e costruttori
 * 
 * Disponibile su devACADEMY.it
 */

public class OverloadMetodiECostruttori {

	public static void main(String[] args) {
		
		Persona p = new Persona("Paolo", "Rossi", 34);
		
		Persona p1 = new Persona("Verdi");
		p1.setNome("Luca");
		p1.setEta(20);
		
		System.out.println(p.nomeCompleto());
		System.out.println(p1.nomeCompleto());
		
	}

}