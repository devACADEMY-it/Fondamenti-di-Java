/*
 * Fondamenti di Java
 * Variabili e tipi di dato
 * 
 * Disponibile su devACADEMY.it
 */

public class EsempioVariabili {

	public static void main(String[] args) {
		
		int numero = 4;
		int a = 5;
		
		System.out.println("Valore: " + numero*a);

	}

}