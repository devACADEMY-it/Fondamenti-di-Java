/*
 * Fondamenti di Java
 * Prima Esercitazione: "Numeri di Fibonacci"
 * 
 * Disponibile su devACADEMY.it
 */

public class PrimaEsercitazioneNumeriDiFibonacci {

	public static void main(String[] args) {
		
		int numeriDiFibonacci[] = new int[12];
		
		numeriDiFibonacci[0] = 1;
		numeriDiFibonacci[1] = 1;
		
		System.out.println(numeriDiFibonacci[0]);
		System.out.println(numeriDiFibonacci[1]);
		
		for (int i=2; i<numeriDiFibonacci.length; i++){
			numeriDiFibonacci[i] = numeriDiFibonacci[i-2]+numeriDiFibonacci[i-1];
			System.out.println(numeriDiFibonacci[i]);
		}

	}

}