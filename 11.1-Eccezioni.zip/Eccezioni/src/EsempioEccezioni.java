/*
 * Fondamenti di Java
 * Le eccezioni
 * 
 * Disponibile su devACADEMY.it
 */

public class EsempioEccezioni {

	public static void main(String[] args) {
		
		int numeri[] = new int[10];
		
		try{
			numeri[10] = 6/0;	// Il calcolo viene eseguito prima dell'assegnazione	
		} catch(ArrayIndexOutOfBoundsException e){
			System.out.println("Errore nell'array");
		} catch(ArithmeticException e) {
			System.out.println("Errore Aritmetico");
		} finally{
			System.out.println("Eseguito comunque...");
		}
		
		System.out.println("FINE PROGRAMMA");

	}

}