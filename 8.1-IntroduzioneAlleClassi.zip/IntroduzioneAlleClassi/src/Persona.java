/*
 * Fondamenti di Java
 * Introduzione alle classi
 * 
 * Disponibile su devACADEMY.it
 */

public class Persona {
	String nome;
	String cognome;
	int eta;
}