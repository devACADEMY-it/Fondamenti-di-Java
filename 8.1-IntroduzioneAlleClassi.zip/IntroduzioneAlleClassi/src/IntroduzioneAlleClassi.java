/*
 * Fondamenti di Java
 * Introduzione alle classi
 * 
 * Disponibile su devACADEMY.it
 */

public class IntroduzioneAlleClassi {

	public static void main(String[] args) {
		
		Persona p = new Persona();
		p.nome = "Carlo";
		p.cognome = "Rossi";
		p.eta = 25;
		
		Persona p1 = new Persona();
		p1.nome = "Roberto";
		p1.cognome = "Bianchi";
		p1.eta = 37;
		
		System.out.println(p.nome + " " + p.cognome + " di anni " + p.eta);
		System.out.println(p1.nome + " " + p1.cognome + " di anni " + p1.eta);

	}

}