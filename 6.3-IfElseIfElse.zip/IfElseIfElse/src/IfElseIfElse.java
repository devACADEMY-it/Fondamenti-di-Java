/*
 * Fondamenti di Java
 * if…else if…else
 * 
 * Disponibile su devACADEMY.it
 */

public class IfElseIfElse {

	public static void main(String[] args) {
		
		int numero = 25;
		
		if (numero < 10){
			System.out.println(numero + " è minore di 10");
		} else if (numero < 50) {
			System.out.println(numero + " è minore di 50 e maggiore di 10");
		} else {
			System.out.println(numero + " è maggiore o uguale a 50");
		}

	}

}