/*
 * Fondamenti di Java
 * Soluzione Quarta Esercitazione: "Rubrica"
 * 
 * Disponibile su devACADEMY.it
 */

public class SoluzioneQuartaEsercitazioneRubrica {

	public static void main(String[] args) {
		
		Rubrica r = new Rubrica();
		
		r.aggiungiContatto(new Contatto("Paolo", "Rossi", "3296474848"));
		r.aggiungiContatto(new Contatto("Silvio", "Rondini", "3345832838"));
		r.aggiungiContatto(new Contatto("Roberto", "Muccino", "3318489037"));
		r.aggiungiContatto(new Contatto("Enzo", "Liberati", "3334827373"));
		r.aggiungiContatto(new Contatto("Enea", "Lucchetti", "3318903748"));
		
		for (Contatto c: r.cercaContattiPerIniziale('R')){
			System.out.println(c.getCognome() + " " + c.getTelefono());
		}

	}

}