/*
 * Fondamenti di Java
 * Soluzione Quarta Esercitazione: "Rubrica"
 * 
 * Disponibile su devACADEMY.it
 */

public class Contatto extends Persona {
	
	private String telefono;

	public Contatto(String nome, String cognome, String telefono) {
		super(nome, cognome);
		this.telefono = telefono;
	}

	public String getTelefono() {
		return telefono;
	}

}