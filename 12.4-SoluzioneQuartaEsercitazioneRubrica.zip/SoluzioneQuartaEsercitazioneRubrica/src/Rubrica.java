/*
 * Fondamenti di Java
 * Soluzione Quarta Esercitazione: "Rubrica"
 * 
 * Disponibile su devACADEMY.it
 */

import java.util.ArrayList;
import java.util.HashMap;

public class Rubrica {
	
	private HashMap<Character, ArrayList<Contatto>> rubrica = new HashMap<Character, ArrayList<Contatto>>();

	public void aggiungiContatto(Contatto c){
		if (!rubrica.containsKey(c.getCognome().charAt(0))) {
			rubrica.put(c.getCognome().charAt(0), new ArrayList<Contatto>());
		}
		rubrica.get(c.getCognome().charAt(0)).add(c);
	}
	
	public ArrayList<Contatto> cercaContattiPerIniziale(char i){
		return rubrica.get(i);
	}
}