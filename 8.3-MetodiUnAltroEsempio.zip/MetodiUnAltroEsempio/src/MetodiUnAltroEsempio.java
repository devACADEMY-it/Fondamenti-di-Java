/*
 * Fondamenti di Java
 * I metodi: un altro esempio
 * 
 * Disponibile su devACADEMY.it
 */

public class MetodiUnAltroEsempio {

	public static void main(String[] args) {
		
		Persona p = new Persona();
		p.nome = "Paolo";
		p.cognome = "Rossi";
		p.eta = 15;
		
		Persona p1 = new Persona();
		p1.nome = "Enzo";
		p1.cognome = "Verdi";
		p1.eta = 56;
		
		String nc = p.nomeCompleto();
		
		if (p.seiMaggiorenne()){
			System.out.println("Sei maggiorenne");
		} else {
			System.out.println("Sei ancora minorenne");
		}

	}

}