/*
 * Fondamenti di Java
 * I metodi: un altro esempio
 * 
 * Disponibile su devACADEMY.it
 */

public class Persona {
	String nome;
	String cognome;
	int eta;
	
	String nomeCompleto(){
		return nome + " " + cognome;
	}
	
	boolean seiMaggiorenne(){
		if (eta >= 18){
			return true; // Se viene eseguito questo return il prossimo verrà saltato
		}
		return false;
	}
}