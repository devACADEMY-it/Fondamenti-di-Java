/*
 * Fondamenti di Java
 * HashMap
 * 
 * Disponibile su devACADEMY.it
 */

import java.util.HashMap;

public class EsempioMappe {

	public static void main(String[] args) {
		
		HashMap<String, Persona> mappa = new HashMap<String, Persona>();
		
		mappa.put("Rossi_Paolo", new Persona("Paolo", "Rossi", 54)); // La chiave deve essere univoca
		
		if (!mappa.containsKey("Rossi")) {
			mappa.put("Rossi", new Persona("Enrico", "Rossi", 22));
		}
		
		Persona p = mappa.get("Rossi");
		
		System.out.println(p.nomeCompleto());

	}

}