/*
 * Fondamenti di Java
 * Soluzione Seconda Esercitazione: "Cerca il più giovane"
 * 
 * Disponibile su devACADEMY.it
 */

public class SoluzioneSecondaEsercitazioneCercaIlPiuGiovane {

	public static void main(String[] args) {
		
		Persona persone[] = new Persona[10];
		
		persone[0] = new Persona("Carlo", "Rossi", 71);
		persone[1] = new Persona("Ernesto", "Bianchi", 25);
		persone[2] = new Persona("Silvio", "Verdi", 53);
		persone[3] = new Persona("Enzo", "Neri", 19);
		persone[4] = new Persona("Enea", "Marroni", 44);

		int posizionePiuGiovane = 0;
		
		for (int i=1; i<persone.length; i++){
			if(persone[i] != null){
				if(persone[posizionePiuGiovane].getEta() > persone[i].getEta()){
					posizionePiuGiovane = i;
				}
			}
		}
		
		System.out.println("Il più giovane è " + persone[posizionePiuGiovane].descrizione());

	}

}