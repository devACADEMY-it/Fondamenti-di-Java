/*
 * Fondamenti di Java
 * Ciclo for: un esempio
 * 
 * Disponibile su devACADEMY.it
 */

public class EsempioCicloFor {

	public static void main(String[] args) {
		
		for ( int i=1; i<=10 ; i++ ) {
			System.out.println(i*2);
		}

	}

}
