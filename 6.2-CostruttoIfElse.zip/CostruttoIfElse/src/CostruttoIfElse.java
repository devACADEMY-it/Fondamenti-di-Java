/*
 * Fondamenti di Java
 * Il costrutto if…else
 * 
 * Disponibile su devACADEMY.it
 */

public class CostruttoIfElse {

	public static void main(String[] args) {
		
		int numero = 5;
		
		if (numero > 10){
			System.out.println(numero + " è maggiore di 10");
		} else {
			System.out.println(numero + " è minore o uguale a 10");
		}
		
		System.out.println("FINE PROGRAMMA");

	}

}