/*
 * Fondamenti di Java
 * I costruttori
 * 
 * Disponibile su devACADEMY.it
 */

public class Costruttori {

	public static void main(String[] args) {
		
		Persona p = new Persona("Paolo", "Rossi", 45);
		
		System.out.println(p.nomeCompleto());

	}

}