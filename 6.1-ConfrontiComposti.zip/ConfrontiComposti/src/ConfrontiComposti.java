/*
 * Fondamenti di Java
 * Confronti composti
 * 
 * Disponibile su devACADEMY.it
 */

public class ConfrontiComposti {

	public static void main(String[] args) {
		
		int numero = 45;
		
		boolean confronto1 = (numero > 30) && (numero <= 50);
		boolean confronto2 = (numero > 30) && (numero > 50);
		boolean confronto3 = (numero > 30) || (numero > 50);
		
		System.out.println(confronto1);
		System.out.println(confronto2);
		System.out.println(confronto3);
		
	}

}