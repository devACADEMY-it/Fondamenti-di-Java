/*
 * Fondamenti di Java
 * Operatori aritmetici
 * 
 * Disponibile su devACADEMY.it
 */

public class OperatoriAritmetici {

	public static void main(String[] args) {
		
		float importo, tasse;
		
		importo = 1500.45f;
		tasse = 234.24f;
		
		importo-=tasse; // importo = importo - tasse
		
		System.out.println("Importo definitivo: " + importo);
		
	}

}
