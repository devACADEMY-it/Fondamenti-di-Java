/*
 * Fondamenti di Java
 * Classi Wrapper
 * 
 * Disponibile su devACADEMY.it
 */

public class ClassiWrapper {

	public static void main(String[] args) {
		
		String numero = "25";
		
		int numeroIntero = Integer.parseInt(numero);
		
		System.out.println(numero+3);
		System.out.println(numeroIntero+3);

	}

}