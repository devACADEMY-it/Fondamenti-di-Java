/*
 * Fondamenti di Java
 * Primo programma in Java
 * 
 * Disponibile su devACADEMY.it
 */

public class Hello {

	public static void main(String[] args) {
		
		// La riga sottostante stampa una stringa in output
		System.out.println("Hello World!");

	}

}
