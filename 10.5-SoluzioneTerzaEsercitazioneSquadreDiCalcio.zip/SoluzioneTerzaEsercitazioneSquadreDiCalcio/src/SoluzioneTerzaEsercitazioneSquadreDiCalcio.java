/*
 * Fondamenti di Java
 * Soluzione Terza Esercitazione: "Squadre di calcio"
 * 
 * Disponibile su devACADEMY.it
 */

public class SoluzioneTerzaEsercitazioneSquadreDiCalcio {

	public static void main(String[] args) {
		
		Squadra s = new Squadra();
		
		s.aggiungiCalciatore(new Calciatore("Luca", "Rossi", 5));
		s.aggiungiCalciatore(new Calciatore("Matteo", "Neri", 8));
		s.aggiungiCalciatore(new Calciatore("Enzo", "Verdi", 0));
		s.aggiungiCalciatore(new Calciatore("Enea", "Bianchi", 7));

		s.stampaFormazione();
	}

}