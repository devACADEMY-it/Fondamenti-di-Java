/*
 * Fondamenti di Java
 * Soluzione Terza Esercitazione: "Squadre di calcio"
 * 
 * Disponibile su devACADEMY.it
 */

import java.util.ArrayList;

public class Squadra {
	
	private ArrayList<Calciatore> rosa = null;
	
	public Squadra(){
		rosa = new ArrayList<Calciatore>();
	}

	public void aggiungiCalciatore(Calciatore c){
		rosa.add(c);
	}
	
	public void stampaFormazione(){
		for (Calciatore c: rosa){
			System.out.println(c.getCognome() + " " + c.getNome() + " ha segnato " + c.getNgoal() + " goal");
		}
	}
}