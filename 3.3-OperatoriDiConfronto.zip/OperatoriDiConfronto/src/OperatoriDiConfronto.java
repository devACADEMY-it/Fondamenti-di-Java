/*
 * Fondamenti di Java
 * Operatori di confronto
 * 
 * Disponibile su devACADEMY.it
 */

public class OperatoriDiConfronto {

	public static void main(String[] args) {
		
		boolean risultato1 = 4 > 5;	
		System.out.println("Risultato1 = " + risultato1);

		boolean risultato2 = 5 == 5;
		System.out.println("Risultato2 = " + risultato2);

		boolean risultato3 = !(5 == 5);
		System.out.println("Risultato3 = " + risultato3);
	}

}