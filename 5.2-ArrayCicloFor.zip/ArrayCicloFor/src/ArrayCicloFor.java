/*
 * Fondamenti di Java
 * Array e ciclo for
 * 
 * Disponibile su devACADEMY.it
 */

public class ArrayCicloFor {

	public static void main(String[] args) {
		
		int [] valori = new int[10];
		
		valori[0] = 40;
		valori[3] = 20;
		valori[5] = 24;
		
		for (int i=0; i<valori.length; i++){
			System.out.println(valori[i]);
		}
		
	}

}